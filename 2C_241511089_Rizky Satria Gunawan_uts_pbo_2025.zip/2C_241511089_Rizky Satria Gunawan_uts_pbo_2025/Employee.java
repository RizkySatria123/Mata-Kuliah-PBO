public interface Employee {
    double getSalary();
}
